module DPL
  Error = Class.new(StandardError)
end
