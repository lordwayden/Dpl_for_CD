module DPL
  VERSION = '1.10.7'
end
