Heroku might send out emails for new deploy keys (doesn't do it for me, but for some others).

Alternative is Anvil, but it's not perfect, as it duplicates a lot of Heroku logic internally (and failed for me in one case).